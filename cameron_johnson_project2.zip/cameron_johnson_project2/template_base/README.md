# Project 2: What Does Community Mean To You?

# project overview
In the (What Does Community Mean To You?) project we review a piece of litature that embodies what community is to the author. Diving deep into lyrics from music artist and breaking down how those words encompass the meaning of connections and more.

# technical overview
This project will contains hovers on imgs and text postioned to where it will not collide with other assests such as text borders etc. Margins and padding are reset to 0 on start and was made in Visual studio code.

# acknowledgment
 Here are some website I am using for concepts and ideas to futher my process 

 https://genius.com/The-weeknd-and-playboi-carti-timeless-lyrics
 https://www.aurision.com/post/artist-highlight-jay-kim